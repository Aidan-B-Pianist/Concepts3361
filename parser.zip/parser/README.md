# A Simple Recursive-Descent Parser

This is the implementation of the parser in pp. 181 - 185 of the textbook

 Sebesta, R. W. (2012). Concepts of Programming Languages. 
 Pearson, 10th edition.

